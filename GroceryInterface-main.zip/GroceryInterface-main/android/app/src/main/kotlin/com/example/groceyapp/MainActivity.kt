package com.example.groceyapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
